# TriMiner — How to Build the APK (Free, No PC Needed)

## What You Need
- A free GitHub account → https://github.com
- The TriMiner project files (this ZIP)
- Your phone to install the APK at the end

---

## STEP 1 — Create a GitHub Account (if you don't have one)
1. Go to **https://github.com**
2. Click **Sign up** → enter email, password, username
3. Verify your email

---

## STEP 2 — Create a New Repository
1. Click the **+** button (top right) → **New repository**
2. Name it: `triminer`
3. Set to **Public**
4. Click **Create repository**

---

## STEP 3 — Upload the Project Files
You need to upload ALL files keeping the folder structure:

```
triminer/           ← upload everything INSIDE this folder
├── main.py
├── buildozer.spec
├── miners/
│   ├── duino_miner.py
│   ├── nimiq_miner.py
│   └── riecoin_miner.py
├── backend/
│   └── pool_monitor.py
└── .github/
    └── workflows/
        └── build.yml
```

### Upload method (easiest on phone/PC):
1. On your new repo page, click **uploading an existing file**
2. Drag and drop ALL files from the ZIP
3. Make sure the folder structure is preserved
4. Click **Commit changes**

> ⚠️ The `.github/workflows/build.yml` file is the most important —
> it tells GitHub to build your APK automatically.

---

## STEP 4 — Watch the Build
1. Click the **Actions** tab in your repo
2. You'll see **"Build TriMiner APK"** running (yellow spinner)
3. Wait **15–25 minutes** for it to finish
4. If it turns **green ✓** → your APK is ready!
5. If it turns **red ✗** → click it, scroll to the error, open an issue

---

## STEP 5 — Download Your APK
1. Click on the completed green workflow run
2. Scroll down to **Artifacts**
3. Click **TriMiner-APK** to download the ZIP
4. Extract it — inside is `triminer-1.0.0-arm64-v8a-debug.apk`

---

## STEP 6 — Install on Android
1. Transfer the APK to your phone (Bluetooth, Google Drive, USB, etc.)
2. On your phone: **Settings → Security → Allow unknown sources** (or "Install unknown apps")
3. Open the APK file → tap **Install**
4. Open **TriMiner** and start mining!

---

## Using the App
1. **Setup screen**: Enter your wallet addresses
   - Duino-Coin: your registered username at https://duinocoin.com
   - Nimiq: your NQ... wallet address
   - Riecoin: your ric1q... wallet address
2. Tap **START MINING ALL**
3. Watch all 3 miners run simultaneously in the dashboard
4. Tap **📊 MONITOR** to see live pool stats, balance, shares

---

## Pools Used (default)
| Coin | Pool | Sign Up |
|------|------|---------|
| Duino-Coin | server.duinocoin.com:2813 | https://duinocoin.com |
| Nimiq | eu.nimpool.io:8444 | https://nimpool.io |
| Riecoin | ric.riesenprime.de:5000 | https://ric.riesenprime.de |

---

## Tips for Best Performance
- In Android Settings, disable **battery optimization** for TriMiner
- Keep screen on OR use a screen lock app that allows background tasks
- Plug in charger while mining — CPU mining drains battery fast
- More threads = more heat + battery drain, tune to your device

---

## Re-triggering the Build
If you update any code and push to GitHub, the APK rebuilds automatically.
You can also trigger it manually:
- Go to **Actions** tab → click **Build TriMiner APK** → **Run workflow**
