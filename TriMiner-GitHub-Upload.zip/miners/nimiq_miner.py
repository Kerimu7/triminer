"""
Nimiq Miner — Argon2d CPU mining via Nimiq Stratum protocol
Pool: eu.nimpool.io:8444  (or any Nimiq stratum pool)
"""

import socket
import json
import threading
import time
import hashlib
import struct
import requests
from datetime import datetime

try:
    from argon2.low_level import hash_secret_raw, Type
    ARGON2_AVAILABLE = True
except ImportError:
    ARGON2_AVAILABLE = False

POOL_HOST = "eu.nimpool.io"
POOL_PORT = 8444
MINER_VER = "TriMiner/1.0"

# Argon2d params (Nimiq spec)
ARGON2_MEMORY    = 512   # KiB
ARGON2_ITERATIONS = 1
ARGON2_PARALLELISM = 1
ARGON2_HASH_LEN  = 32


class NimiqMiner:
    def __init__(self, wallet_address, threads=2, pool_host=POOL_HOST, pool_port=POOL_PORT,
                 on_status=None, on_share=None, on_hashrate=None):
        self.wallet    = wallet_address
        self.threads   = threads
        self.pool_host = pool_host
        self.pool_port = pool_port
        self.on_status = on_status
        self.on_share  = on_share
        self.on_hashrate = on_hashrate

        self.running   = False
        self.accepted  = 0
        self.rejected  = 0
        self._job      = None
        self._job_lock = threading.Lock()
        self._sock     = None
        self._msg_id   = 1
        self._hashrates = {}
        self._hr_lock  = threading.Lock()

    # ── public ────────────────────────────────────────────────────────────────
    def start(self):
        if not ARGON2_AVAILABLE:
            self._emit("argon2-cffi not installed. Run: pip install argon2-cffi", "err")
            return
        self.running = True
        threading.Thread(target=self._network_loop, daemon=True).start()
        threading.Thread(target=self._aggregate_hashrate, daemon=True).start()
        self._emit("Connecting to Nimiq pool…", "info")

    def stop(self):
        self.running = False
        if self._sock:
            try: self._sock.close()
            except: pass
        self._emit("Miner stopped.", "warn")

    def get_stats(self):
        """Fetch miner stats from Nimpool API."""
        try:
            url = f"https://nimpool.io/api/miner/{self.wallet}"
            r = requests.get(url, timeout=8)
            return r.json()
        except Exception:
            return {}

    def get_pool_stats(self):
        try:
            r = requests.get("https://nimpool.io/api/pool", timeout=8)
            return r.json()
        except Exception:
            return {}

    # ── network / stratum ──────────────────────────────────────────────────────
    def _network_loop(self):
        while self.running:
            try:
                self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self._sock.settimeout(60)
                self._sock.connect((self.pool_host, self.pool_port))
                self._emit(f"Connected to {self.pool_host}:{self.pool_port}", "info")

                # Subscribe
                self._send({"method": "mining.subscribe",
                            "params": [MINER_VER], "id": self._next_id()})
                # Authorize
                self._send({"method": "mining.authorize",
                            "params": [self.wallet, "x"], "id": self._next_id()})

                buf = ""
                while self.running:
                    data = self._sock.recv(4096).decode(errors="ignore")
                    if not data:
                        break
                    buf += data
                    while "\n" in buf:
                        line, buf = buf.split("\n", 1)
                        self._handle_message(json.loads(line.strip()))

            except Exception as e:
                self._emit(f"Connection error: {e} — reconnecting…", "err")
                time.sleep(5)

    def _handle_message(self, msg):
        method = msg.get("method", "")
        if method == "mining.notify":
            params = msg["params"]
            with self._job_lock:
                self._job = {
                    "job_id":   params[0],
                    "prev_hash": params[1],
                    "body":     params[2],
                    "nonce":    int(params[3], 16) if len(params) > 3 else 0,
                    "target":   params[4] if len(params) > 4 else "f" * 64,
                }
            self._emit(f"New job: {params[0][:12]}…", "info")
            self._spawn_workers()

        elif method == "mining.set_difficulty":
            diff = msg["params"][0]
            self._emit(f"Difficulty set to {diff}", "info")

        elif "result" in msg:
            if msg.get("result") is True:
                self.accepted += 1
                self._emit(f"✓ Share accepted [{self.accepted}]", "ok")
            elif msg.get("result") is False:
                self.rejected += 1
                self._emit(f"✗ Share rejected", "warn")
            if self.on_share:
                self.on_share(self.accepted, self.rejected)

    def _spawn_workers(self):
        for i in range(self.threads):
            t = threading.Thread(target=self._mine_worker, args=(i,), daemon=True)
            t.start()

    def _mine_worker(self, wid):
        with self._job_lock:
            job = dict(self._job) if self._job else None
        if not job:
            return

        nonce_start = job["nonce"] + wid * 100000
        nonce       = nonce_start
        t0          = time.time()
        hashes      = 0
        target_bytes = bytes.fromhex(job["target"].ljust(64, "0"))[:8]

        while self.running:
            with self._job_lock:
                if self._job and self._job["job_id"] != job["job_id"]:
                    break  # stale

            block_header = bytes.fromhex(job["prev_hash"]) + \
                           bytes.fromhex(job["body"][:64].ljust(64, "0")) + \
                           struct.pack("<I", nonce)

            digest = hash_secret_raw(
                secret=block_header,
                salt=block_header[:16],
                time_cost=ARGON2_ITERATIONS,
                memory_cost=ARGON2_MEMORY,
                parallelism=ARGON2_PARALLELISM,
                hash_len=ARGON2_HASH_LEN,
                type=Type.D
            )

            hashes += 1
            elapsed = time.time() - t0
            if elapsed >= 2:
                with self._hr_lock:
                    self._hashrates[wid] = hashes / elapsed
                hashes = 0
                t0 = time.time()

            if digest[:8] <= target_bytes:
                self._submit_share(job["job_id"], nonce)
                break

            nonce += 1

    def _submit_share(self, job_id, nonce):
        self._send({
            "method": "mining.submit",
            "params": [self.wallet, job_id, hex(nonce)],
            "id": self._next_id()
        })

    def _send(self, obj):
        try:
            self._sock.send((json.dumps(obj) + "\n").encode())
        except Exception as e:
            self._emit(f"Send error: {e}", "err")

    def _next_id(self):
        self._msg_id += 1
        return self._msg_id

    def _aggregate_hashrate(self):
        while self.running:
            time.sleep(2)
            with self._hr_lock:
                total = sum(self._hashrates.values())
            if self.on_hashrate:
                self.on_hashrate(total)

    def _emit(self, msg, level="info"):
        ts = datetime.now().strftime("%H:%M:%S")
        if self.on_status:
            self.on_status(f"[{ts}] {msg}", level)
