"""
Duino-Coin Miner — Official DUCO-S1 / DUCO-S1A protocol
Connects to official pool: server.duinocoin.com:2813
"""

import socket
import hashlib
import threading
import time
import random
import queue
import requests
from datetime import datetime

POOL_HOST = "server.duinocoin.com"
POOL_PORT = 2813
SERVER_VER_REQUIRED = "3."
MINER_VER = "TriMiner/1.0"

class DuinoMiner:
    def __init__(self, username, password="", threads=2, on_status=None, on_share=None, on_hashrate=None):
        self.username   = username
        self.password   = password
        self.threads    = threads
        self.on_status  = on_status   # callback(msg, level)
        self.on_share   = on_share    # callback(accepted, rejected)
        self.on_hashrate= on_hashrate # callback(h/s)

        self.running    = False
        self.accepted   = 0
        self.rejected   = 0
        self._workers   = []
        self._hashrates = {}
        self._lock      = threading.Lock()

    # ── public ────────────────────────────────────────────────────────────────
    def start(self):
        self.running = True
        self._emit("Connecting to Duino-Coin pool…", "info")
        for i in range(self.threads):
            t = threading.Thread(target=self._worker, args=(i,), daemon=True)
            t.start()
            self._workers.append(t)
        # hashrate aggregator
        threading.Thread(target=self._aggregate_hashrate, daemon=True).start()

    def stop(self):
        self.running = False
        self._emit("Miner stopped.", "warn")

    def get_balance(self):
        """Fetch live balance from Duino API."""
        try:
            url = f"https://server.duinocoin.com/v4/users/{self.username}"
            r = requests.get(url, timeout=8)
            data = r.json()
            if data.get("result"):
                bal = data["result"].get("balance", {}).get("balance", 0)
                return round(float(bal), 6)
        except Exception:
            pass
        return None

    def get_pool_stats(self):
        """Fetch server statistics."""
        try:
            r = requests.get("https://server.duinocoin.com/v4/statistics", timeout=8)
            return r.json()
        except Exception:
            return {}

    # ── internal ──────────────────────────────────────────────────────────────
    def _worker(self, worker_id):
        sock = None
        while self.running:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(30)
                sock.connect((POOL_HOST, POOL_PORT))

                server_ver = sock.recv(100).decode().strip()
                self._emit(f"[W{worker_id}] Server v{server_ver}", "info")

                # Request job
                while self.running:
                    sock.send(f"JOB,{self.username},LOW\n".encode())
                    job_raw = sock.recv(256).decode().strip()
                    parts = job_raw.split(",")
                    if len(parts) < 3:
                        continue

                    last_hash, expected_hash, difficulty = parts[0], parts[1], int(parts[2])
                    self._emit(f"[W{worker_id}] Job diff={difficulty}", "info")

                    result, h_count, elapsed = self._duco_s1(last_hash, expected_hash, difficulty, worker_id)

                    hashrate = int(h_count / elapsed) if elapsed > 0 else 0
                    with self._lock:
                        self._hashrates[worker_id] = hashrate

                    sock.send(f"{result},{hashrate},{MINER_VER},MEDIUM\n".encode())
                    feedback = sock.recv(64).decode().strip()

                    if feedback.upper().startswith("GOOD"):
                        self.accepted += 1
                        self._emit(f"[W{worker_id}] ✓ Share accepted [{self.accepted}]", "ok")
                    elif feedback.upper().startswith("BAD"):
                        self.rejected += 1
                        self._emit(f"[W{worker_id}] ✗ Share rejected", "warn")

                    if self.on_share:
                        self.on_share(self.accepted, self.rejected)

            except Exception as e:
                self._emit(f"[W{worker_id}] Error: {e} — retrying in 5s", "err")
                time.sleep(5)
            finally:
                if sock:
                    try: sock.close()
                    except: pass

    def _duco_s1(self, last_hash, expected_hash, difficulty, worker_id):
        """DUCO-S1 proof-of-work: find nonce such that SHA1(last_hash+nonce)==expected_hash."""
        start = time.time()
        h_count = 0
        for nonce in range(difficulty * 100 + 1):
            if not self.running:
                break
            digest = hashlib.sha1(f"{last_hash}{nonce}".encode()).hexdigest()
            h_count += 1
            if digest == expected_hash:
                elapsed = time.time() - start
                return nonce, h_count, max(elapsed, 0.001)
        elapsed = time.time() - start
        return 0, h_count, max(elapsed, 0.001)

    def _aggregate_hashrate(self):
        while self.running:
            time.sleep(2)
            with self._lock:
                total = sum(self._hashrates.values())
            if self.on_hashrate:
                self.on_hashrate(total)

    def _emit(self, msg, level="info"):
        ts = datetime.now().strftime("%H:%M:%S")
        if self.on_status:
            self.on_status(f"[{ts}] {msg}", level)
