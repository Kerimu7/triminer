## TriMiner — Requirements & Build Guide

### Python Dependencies
```
pip install kivy==2.3.0 requests argon2-cffi buildozer
```

### Project Structure
```
triminer/
├── main.py                  ← Kivy app (UI + app logic)
├── buildozer.spec           ← Android APK config
├── miners/
│   ├── duino_miner.py       ← Real DUCO-S1 SHA-1 miner
│   ├── nimiq_miner.py       ← Real Argon2d stratum miner
│   └── riecoin_miner.py     ← Real prime constellation miner
└── backend/
    └── pool_monitor.py      ← Live pool/API stats fetcher
```

### Build APK (Linux/macOS)
```bash
cd triminer
pip install buildozer
buildozer android debug    # first build ~20 min
buildozer android deploy   # install on connected device
```

### Pools Used
| Coin       | Pool                          | API                                     |
|------------|-------------------------------|-----------------------------------------|
| Duino-Coin | server.duinocoin.com:2813     | server.duinocoin.com/v4/users/{user}    |
| Nimiq      | eu.nimpool.io:8444            | nimpool.io/api/miner/{wallet}           |
| Riecoin    | ric.riesenprime.de:5000       | ric.riesenprime.de/api/miner/{wallet}   |

### Wallet Address Formats
- **Duino-Coin**: your registered username (e.g. `MyName`)
- **Nimiq**: NQ-format address (e.g. `NQ07 XXXX XXXX …`)
- **Riecoin**: bech32 address (e.g. `ric1qxxx…`)

### Android Notes
- Requires Android 8.0+ (API 26)
- Uses WAKE_LOCK permission to mine in background
- Keep screen on or enable battery optimization exemption for best results
- arm64-v8a (most modern phones) + armeabi-v7a (older) both supported
