"""
TriMiner — Main Kivy Application
Full Android CPU miner: Duino-Coin + Nimiq + Riecoin
"""

import threading
import time
import sys
import os

# Add miners/backend to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "miners"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "backend"))

from kivy.app import App
from kivy.clock import Clock
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget
from kivy.graphics import Color, Rectangle, RoundedRectangle, Line
from kivy.utils import get_color_from_hex
from kivy.metrics import dp
from kivy.core.window import Window
from kivy.uix.slider import Slider
from kivy.properties import StringProperty, NumericProperty, BooleanProperty

from duino_miner import DuinoMiner
from nimiq_miner import NimiqMiner
from riecoin_miner import RiecoinMiner
from pool_monitor import PoolMonitor

# ── Color Palette ─────────────────────────────────────────────────────────────
BG       = get_color_from_hex("#060a0f")
PANEL    = get_color_from_hex("#0b1118")
BORDER   = get_color_from_hex("#1a2535")
TEXT     = get_color_from_hex("#c8d8e8")
DIM      = get_color_from_hex("#4a6070")
DUINO_C  = get_color_from_hex("#f7c948")
NIMIQ_C  = get_color_from_hex("#1a9aff")
RIEC_C   = get_color_from_hex("#00e5a0")
GREEN    = get_color_from_hex("#00ff88")
RED      = get_color_from_hex("#ff4455")
YELLOW   = get_color_from_hex("#ffaa00")

Window.clearcolor = BG


# ── Helpers ───────────────────────────────────────────────────────────────────
def fmt_hash(val, unit="H/s"):
    if val >= 1_000_000: return f"{val/1_000_000:.2f} M{unit}"
    if val >= 1_000:     return f"{val/1_000:.2f} K{unit}"
    return f"{val:.1f} {unit}"

def make_label(text, size=14, color=TEXT, bold=False, halign="left", **kw):
    lbl = Label(text=text, font_size=dp(size), color=color,
                bold=bold, halign=halign, **kw)
    lbl.bind(size=lbl.setter("text_size"))
    return lbl

def dark_button(text, color=DUINO_C, callback=None, height=dp(44)):
    btn = Button(
        text=text, size_hint_y=None, height=height,
        background_normal="", background_color=(*color[:3], 0.15),
        color=color, bold=True, font_size=dp(13),
        border=(2, 2, 2, 2)
    )
    with btn.canvas.before:
        Color(*color[:3], 0.7)
        btn._border_line = Line(rounded_rectangle=(0, 0, 100, height, dp(4)), width=1.2)
    def update_border(inst, val):
        inst._border_line.rounded_rectangle = (*inst.pos, *inst.size, dp(4))
    btn.bind(pos=update_border, size=update_border)
    if callback:
        btn.bind(on_press=callback)
    return btn


# ═══════════════════════════════════════════════════════════════════════════════
# SCREEN 1 — Wallet Setup
# ═══════════════════════════════════════════════════════════════════════════════
class SetupScreen(Screen):
    def __init__(self, app_ref, **kw):
        super().__init__(**kw)
        self.app = app_ref
        self._build()

    def _build(self):
        root = BoxLayout(orientation="vertical", padding=dp(16), spacing=dp(10))

        # Header
        hdr = BoxLayout(size_hint_y=None, height=dp(60))
        hdr.add_widget(make_label("⛏ TRIMINER SETUP", size=20, color=DUINO_C,
                                   bold=True, halign="center", size_hint_x=1))
        root.add_widget(hdr)
        root.add_widget(make_label("Enter your wallet addresses to begin mining.",
                                    size=12, color=DIM, halign="center"))

        scroll = ScrollView()
        form   = BoxLayout(orientation="vertical", spacing=dp(14),
                           size_hint_y=None, padding=[0, dp(8), 0, dp(8)])
        form.bind(minimum_height=form.setter("height"))

        # ── Duino-Coin ──
        form.add_widget(self._section_header("🪙 DUINO-COIN", DUINO_C))
        self.duino_user = self._input("Username / Wallet", hint="e.g. MyDuinoUser")
        self.duino_pass = self._input("Password (optional)", hint="leave blank for no-pass", password=True)
        self.duino_threads = self._thread_slider("Threads", DUINO_C)
        form.add_widget(self.duino_user)
        form.add_widget(self.duino_pass)
        form.add_widget(self.duino_threads["layout"])

        # ── Nimiq ──
        form.add_widget(self._section_header("⬡ NIMIQ", NIMIQ_C))
        self.nimiq_wallet = self._input("NQ Wallet Address", hint="e.g. NQ07 …")
        self.nimiq_pool   = self._input("Pool Host", hint="eu.nimpool.io:8444")
        self.nimiq_threads = self._thread_slider("Threads", NIMIQ_C)
        form.add_widget(self.nimiq_wallet)
        form.add_widget(self.nimiq_pool)
        form.add_widget(self.nimiq_threads["layout"])

        # ── Riecoin ──
        form.add_widget(self._section_header("✦ RIECOIN", RIEC_C))
        self.riec_wallet = self._input("RIC Wallet Address", hint="e.g. ric1q…")
        self.riec_pool   = self._input("Pool Host", hint="ric.riesenprime.de:5000")
        self.riec_threads = self._thread_slider("Threads", RIEC_C)
        form.add_widget(self.riec_wallet)
        form.add_widget(self.riec_pool)
        form.add_widget(self.riec_threads["layout"])

        scroll.add_widget(form)
        root.add_widget(scroll)

        # Start button
        start_btn = dark_button("▶  START MINING ALL", color=GREEN,
                                callback=self._on_start, height=dp(52))
        root.add_widget(start_btn)
        self.add_widget(root)

    def _section_header(self, text, color):
        box = BoxLayout(size_hint_y=None, height=dp(32))
        with box.canvas.before:
            Color(*color[:3], 0.1)
            box._bg = Rectangle(pos=box.pos, size=box.size)
        box.bind(pos=lambda i, v: setattr(i._bg, "pos", v),
                 size=lambda i, v: setattr(i._bg, "size", v))
        box.add_widget(make_label(f"  {text}", size=13, color=color, bold=True))
        return box

    def _input(self, label_text, hint="", password=False):
        box = BoxLayout(orientation="vertical", size_hint_y=None, height=dp(66), spacing=dp(2))
        box.add_widget(make_label(label_text, size=11, color=DIM))
        ti = TextInput(
            hint_text=hint, password=password,
            multiline=False, size_hint_y=None, height=dp(40),
            background_color=PANEL,
            foreground_color=TEXT,
            hint_text_color=DIM,
            cursor_color=DUINO_C,
            font_size=dp(13), padding=[dp(10), dp(10)]
        )
        box.add_widget(ti)
        return box

    def _thread_slider(self, label, color):
        box = BoxLayout(size_hint_y=None, height=dp(50), spacing=dp(8))
        box.add_widget(make_label(label, size=11, color=DIM, size_hint_x=0.3))
        sl = Slider(min=1, max=4, value=2, step=1,
                    size_hint_x=0.5,
                    cursor_size=(dp(20), dp(20)),
                    value_track=True, value_track_color=[*color[:3], 1])
        val_lbl = make_label("2", size=13, color=color, bold=True,
                              size_hint_x=0.2, halign="center")
        sl.bind(value=lambda i, v: setattr(val_lbl, "text", str(int(v))))
        box.add_widget(sl)
        box.add_widget(val_lbl)
        return {"layout": box, "slider": sl}

    def _on_start(self, *_):
        # Collect config
        self.app.config = {
            "duino_user":    self.duino_user.children[0].text.strip(),
            "duino_pass":    self.duino_pass.children[0].text.strip(),
            "duino_threads": int(self.duino_threads["slider"].value),
            "nimiq_wallet":  self.nimiq_wallet.children[0].text.strip(),
            "nimiq_pool":    self.nimiq_pool.children[0].text.strip() or "eu.nimpool.io:8444",
            "nimiq_threads": int(self.nimiq_threads["slider"].value),
            "riec_wallet":   self.riec_wallet.children[0].text.strip(),
            "riec_pool":     self.riec_pool.children[0].text.strip() or "ric.riesenprime.de:5000",
            "riec_threads":  int(self.riec_threads["slider"].value),
        }
        self.app.start_all_miners()
        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = "dashboard"


# ═══════════════════════════════════════════════════════════════════════════════
# SCREEN 2 — Mining Dashboard (3 columns)
# ═══════════════════════════════════════════════════════════════════════════════
class DashboardScreen(Screen):
    def __init__(self, app_ref, **kw):
        super().__init__(**kw)
        self.app = app_ref
        self._build()

    def _build(self):
        root = BoxLayout(orientation="vertical")

        # ── Top bar ──
        topbar = BoxLayout(size_hint_y=None, height=dp(48), padding=[dp(12), dp(6)],
                           spacing=dp(8))
        with topbar.canvas.before:
            Color(*PANEL)
            topbar._bg = Rectangle(pos=topbar.pos, size=topbar.size)
        topbar.bind(pos=lambda i,v: setattr(i._bg,"pos",v),
                    size=lambda i,v: setattr(i._bg,"size",v))

        topbar.add_widget(make_label("⛏ TRIMINER", size=15, color=DUINO_C,
                                      bold=True, size_hint_x=0.35))
        self.lbl_total = make_label("0 H/s", size=12, color=GREEN,
                                     bold=True, size_hint_x=0.3, halign="center")
        topbar.add_widget(self.lbl_total)

        btn_monitor = dark_button("📊 MONITOR", color=NIMIQ_C,
                                  height=dp(34), callback=self._go_monitor)
        btn_monitor.size_hint_x = 0.2
        topbar.add_widget(btn_monitor)

        btn_stop = dark_button("■ STOP ALL", color=RED,
                               height=dp(34), callback=self._stop_all)
        btn_stop.size_hint_x = 0.15
        topbar.add_widget(btn_stop)

        root.add_widget(topbar)

        # ── Summary strip ──
        strip = BoxLayout(size_hint_y=None, height=dp(28), padding=[dp(8), 0])
        with strip.canvas.before:
            Color(0.04, 0.07, 0.1, 1)
            strip._bg = Rectangle(pos=strip.pos, size=strip.size)
        strip.bind(pos=lambda i,v: setattr(i._bg,"pos",v),
                   size=lambda i,v: setattr(i._bg,"size",v))
        self.lbl_uptime   = make_label("UP: 00:00:00", size=10, color=DIM, size_hint_x=0.4)
        self.lbl_accepted = make_label("✓ 0", size=10, color=GREEN, size_hint_x=0.3, halign="center")
        self.lbl_temp     = make_label("CPU --°C", size=10, color=YELLOW, size_hint_x=0.3, halign="right")
        strip.add_widget(self.lbl_uptime)
        strip.add_widget(self.lbl_accepted)
        strip.add_widget(self.lbl_temp)
        root.add_widget(strip)

        # ── Three columns ──
        cols = BoxLayout(spacing=0, padding=0)
        self.col_duino   = MinerColumn("duino",   DUINO_C, "🪙", "DUINO",   "DUCO-S1",   "H/s",  self.app)
        self.col_nimiq   = MinerColumn("nimiq",   NIMIQ_C, "⬡", "NIMIQ",   "Argon2d",   "H/s",  self.app)
        self.col_riecoin = MinerColumn("riecoin", RIEC_C,  "✦", "RIECOIN", "Prime Cst", "P/s",  self.app)
        cols.add_widget(self.col_duino)
        cols.add_widget(self.col_nimiq)
        cols.add_widget(self.col_riecoin)
        root.add_widget(cols)

        self.add_widget(root)

        # Refresh clock
        Clock.schedule_interval(self._refresh, 2)
        self._start_time = time.time()

    def _refresh(self, dt):
        s = self.app.state
        # Uptime
        up = int(time.time() - self._start_time)
        h, rem = divmod(up, 3600); m, sec = divmod(rem, 60)
        self.lbl_uptime.text = f"UP: {h:02d}:{m:02d}:{sec:02d}"

        # Total hashrate
        total = (s["duino"]["hashrate"] + s["nimiq"]["hashrate"] + s["riecoin"]["hashrate"])
        self.lbl_total.text = fmt_hash(total)

        # Accepted
        total_acc = sum(s[c]["accepted"] for c in ["duino","nimiq","riecoin"])
        self.lbl_accepted.text = f"✓ {total_acc} accepted"

        # Columns
        self.col_duino.update(s["duino"])
        self.col_nimiq.update(s["nimiq"])
        self.col_riecoin.update(s["riecoin"])

    def _go_monitor(self, *_):
        self.manager.transition = SlideTransition(direction="left")
        self.manager.current = "monitor"

    def _stop_all(self, *_):
        self.app.stop_all_miners()
        self.manager.transition = SlideTransition(direction="right")
        self.manager.current = "setup"


# ═══════════════════════════════════════════════════════════════════════════════
# Miner Column widget
# ═══════════════════════════════════════════════════════════════════════════════
class MinerColumn(BoxLayout):
    def __init__(self, coin_id, color, icon, name, algo, unit, app_ref, **kw):
        super().__init__(orientation="vertical", spacing=dp(2),
                         padding=[dp(4), dp(4)], **kw)
        self.coin_id = coin_id
        self.color   = color
        self.unit    = unit
        self.app     = app_ref

        # Top accent line
        with self.canvas.before:
            Color(*color)
            self._accent = Rectangle(size=(0, dp(3)))
            Color(*BORDER)
            self._right_line = Line(points=[0,0,0,0], width=dp(0.5))

        self.bind(pos=self._update_canvas, size=self._update_canvas)

        # Coin header
        hdr = BoxLayout(size_hint_y=None, height=dp(58), orientation="vertical")
        icon_lbl = make_label(f"{icon} {name}", size=12, color=color, bold=True, halign="center")
        algo_lbl = make_label(algo, size=9, color=DIM, halign="center")
        self.status_lbl = make_label("● IDLE", size=9, color=DIM, halign="center")
        hdr.add_widget(icon_lbl)
        hdr.add_widget(algo_lbl)
        hdr.add_widget(self.status_lbl)
        self.add_widget(hdr)

        # Big hashrate
        self.hash_lbl = make_label("0", size=22, color=color, bold=True, halign="center")
        self.unit_lbl = make_label(unit, size=9, color=DIM, halign="center")
        self.add_widget(self.hash_lbl)
        self.add_widget(self.unit_lbl)

        # Stats
        self.shares_lbl  = self._stat_row("Shares",   "0")
        self.reject_lbl  = self._stat_row("Rejected", "0")
        self.diff_lbl    = self._stat_row("Diff",     "--")
        self.earned_lbl  = self._stat_row("Earned",   "0.000")

        # Toggle button
        self.toggle_btn = Button(
            text="▶ START", size_hint_y=None, height=dp(36),
            background_normal="", background_color=(*color[:3], 0.2),
            color=color, bold=True, font_size=dp(11)
        )
        self.toggle_btn.bind(on_press=self._toggle)
        self.add_widget(self.toggle_btn)

        # Log
        self.log_scroll = ScrollView(size_hint_y=None, height=dp(80))
        self.log_box = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(1))
        self.log_box.bind(minimum_height=self.log_box.setter("height"))
        self.log_scroll.add_widget(self.log_box)
        self.add_widget(self.log_scroll)

    def _stat_row(self, label, value):
        row = BoxLayout(size_hint_y=None, height=dp(22))
        row.add_widget(make_label(label, size=9, color=DIM, size_hint_x=0.5))
        val_lbl = make_label(value, size=10, color=self.color, bold=True,
                              size_hint_x=0.5, halign="right")
        row.add_widget(val_lbl)
        self.add_widget(row)
        return val_lbl

    def _update_canvas(self, *_):
        self._accent.pos  = (self.x, self.top - dp(3))
        self._accent.size = (self.width, dp(3))
        self._right_line.points = [self.right, self.y, self.right, self.top]

    def update(self, state):
        """Called every 2s from dashboard clock."""
        hr = state["hashrate"]
        # Format hashrate
        if hr >= 1000:
            self.hash_lbl.text = f"{hr/1000:.2f}K"
        else:
            self.hash_lbl.text = f"{hr:.1f}"

        self.shares_lbl.text  = str(state["accepted"])
        self.reject_lbl.text  = str(state["rejected"])
        self.diff_lbl.text    = str(state.get("diff", "--"))
        earned = state.get("earned", 0)
        self.earned_lbl.text  = f"{earned:.5f}"

        running = state["running"]
        if running:
            self.status_lbl.text  = "● MINING"
            self.status_lbl.color = GREEN
            self.toggle_btn.text  = "■ STOP"
            self.toggle_btn.background_color = (0.6, 0.1, 0.1, 0.3)
            self.toggle_btn.color = RED
        else:
            self.status_lbl.text  = "● IDLE"
            self.status_lbl.color = DIM
            self.toggle_btn.text  = "▶ START"
            self.toggle_btn.background_color = (*self.color[:3], 0.2)
            self.toggle_btn.color = self.color

        # Add new log entries
        logs = state.get("new_logs", [])
        for msg, level in logs:
            self._add_log(msg, level)
        state["new_logs"] = []

    def _add_log(self, msg, level="ok"):
        c = {"ok": GREEN, "warn": YELLOW, "err": RED, "info": DIM}.get(level, TEXT)
        lbl = make_label(msg, size=8, color=c)
        lbl.size_hint_y = None
        lbl.height = dp(14)
        self.log_box.add_widget(lbl)
        if len(self.log_box.children) > 40:
            self.log_box.remove_widget(self.log_box.children[-1])
        self.log_scroll.scroll_y = 0

    def _toggle(self, *_):
        if self.app.state[self.coin_id]["running"]:
            self.app.stop_miner(self.coin_id)
        else:
            self.app.start_miner(self.coin_id)


# ═══════════════════════════════════════════════════════════════════════════════
# SCREEN 3 — Monitoring (tabs for each coin)
# ═══════════════════════════════════════════════════════════════════════════════
class MonitorScreen(Screen):
    def __init__(self, app_ref, **kw):
        super().__init__(**kw)
        self.app = app_ref
        self._active_tab = "duino"
        self._build()

    def _build(self):
        root = BoxLayout(orientation="vertical")

        # Top bar
        topbar = BoxLayout(size_hint_y=None, height=dp(48), padding=[dp(8), dp(6)],
                           spacing=dp(6))
        with topbar.canvas.before:
            Color(*PANEL)
            topbar._bg = Rectangle(pos=topbar.pos, size=topbar.size)
        topbar.bind(pos=lambda i,v: setattr(i._bg,"pos",v),
                    size=lambda i,v: setattr(i._bg,"size",v))

        back_btn = dark_button("◀ BACK", color=DIM, height=dp(34),
                               callback=self._go_back)
        back_btn.size_hint_x = 0.25
        topbar.add_widget(back_btn)
        topbar.add_widget(make_label("📊 POOL MONITOR", size=14, color=TEXT,
                                      bold=True, halign="center"))
        self.refresh_btn = dark_button("↻ REFRESH", color=NIMIQ_C, height=dp(34),
                                       callback=self._refresh_now)
        self.refresh_btn.size_hint_x = 0.25
        topbar.add_widget(self.refresh_btn)
        root.add_widget(topbar)

        # Tab bar
        tabs = BoxLayout(size_hint_y=None, height=dp(40), spacing=0)
        self.tab_btns = {}
        for coin, label, color in [("duino","🪙 DUINO",DUINO_C),
                                    ("nimiq","⬡ NIMIQ",NIMIQ_C),
                                    ("riecoin","✦ RIECOIN",RIEC_C)]:
            btn = Button(text=label, background_normal="",
                         background_color=(*color[:3], 0.15),
                         color=color, font_size=dp(11), bold=True)
            btn.bind(on_press=lambda x, c=coin: self._switch_tab(c))
            tabs.add_widget(btn)
            self.tab_btns[coin] = btn
        root.add_widget(tabs)

        # Content area (scrollable)
        self.scroll = ScrollView()
        self.content = BoxLayout(orientation="vertical", spacing=dp(8),
                                 padding=[dp(12), dp(8)],
                                 size_hint_y=None)
        self.content.bind(minimum_height=self.content.setter("height"))
        self.scroll.add_widget(self.content)
        root.add_widget(self.scroll)

        self.add_widget(root)
        Clock.schedule_interval(self._auto_refresh, 30)
        self._switch_tab("duino")

    def _switch_tab(self, coin):
        self._active_tab = coin
        for c, btn in self.tab_btns.items():
            colors = {"duino": DUINO_C, "nimiq": NIMIQ_C, "riecoin": RIEC_C}
            col = colors[c]
            btn.background_color = (*col[:3], 0.3 if c == coin else 0.1)
        self._render_tab(coin)

    def _render_tab(self, coin):
        self.content.clear_widgets()
        data = self.app.monitor_data.get(coin, {})
        color = {"duino": DUINO_C, "nimiq": NIMIQ_C, "riecoin": RIEC_C}[coin]

        if not data:
            self.content.add_widget(
                make_label("⏳ Fetching pool data… (starts after miner connects)",
                            size=12, color=DIM, halign="center"))
            return

        if "error" in data:
            self.content.add_widget(
                make_label(f"⚠ API Error: {data['error']}", size=12, color=RED))
            return

        # MY MINER stats
        self._section("MY MINER STATS", color)
        miner_fields = {
            "duino":   [("Balance", f"{data.get('balance',0):.6f} DUCO"),
                        ("Hashrate", str(data.get("hashrate","--"))),
                        ("Workers", str(data.get("workers","--")))],
            "nimiq":   [("Balance", f"{data.get('balance',0)} NIM"),
                        ("Hashrate", fmt_hash(float(data.get("hashrate",0)))),
                        ("Valid Shares", str(data.get("shares_valid","--"))),
                        ("Invalid", str(data.get("shares_invalid","--"))),
                        ("Last Share", str(data.get("last_share","--")))],
            "riecoin": [("Balance", f"{data.get('balance',0)} RIC"),
                        ("Hashrate", fmt_hash(float(data.get("hashrate",0)), "P/s")),
                        ("Valid Shares", str(data.get("shares_valid","--"))),
                        ("Stale", str(data.get("shares_stale","--"))),
                        ("Tuple Type", str(data.get("tuple_type","--")))]
        }
        for label, val in miner_fields.get(coin, []):
            self._stat_card(label, val, color)

        # POOL stats
        self._section("POOL STATS", DIM)
        pool_fields = {
            "duino":   [("Pool Hashrate", str(data.get("pool_hashrate","--"))),
                        ("Active Miners", str(data.get("active_miners","--"))),
                        ("Difficulty", str(data.get("difficulty","--"))),
                        ("DUCO Price USD", str(data.get("price_usd","--"))),
                        ("Blocks Found", str(data.get("blocks_found","--")))],
            "nimiq":   [("Pool Hashrate", fmt_hash(float(data.get("pool_hashrate",0)))),
                        ("Pool Miners", str(data.get("pool_miners","--"))),
                        ("Pool Fee", str(data.get("pool_fee","--"))),
                        ("Block Time", str(data.get("block_time","--"))),
                        ("NIM Price USD", str(data.get("nim_price_usd","--"))),
                        ("Last Block", str(data.get("last_block","--")))],
            "riecoin": [("Pool Hashrate", str(data.get("pool_hashrate","--"))),
                        ("Pool Miners", str(data.get("pool_miners","--"))),
                        ("Pool Fee", str(data.get("pool_fee","--"))),
                        ("RIC Price USD", str(data.get("ric_price_usd","--"))),
                        ("Last Block", str(data.get("last_block","--"))),
                        ("Network Diff", str(data.get("network_diff","--")))]
        }
        for label, val in pool_fields.get(coin, []):
            self._stat_card(label, val, TEXT)

        updated = data.get("last_updated","--")
        self.content.add_widget(
            make_label(f"Last updated: {updated}  (auto-refreshes every 30s)",
                        size=9, color=DIM, halign="center"))

    def _section(self, title, color):
        lbl = make_label(f"  {title}", size=11, color=color, bold=True)
        lbl.size_hint_y = None
        lbl.height = dp(28)
        with lbl.canvas.before:
            Color(*color[:3], 0.1)
            lbl._bg = Rectangle(pos=lbl.pos, size=lbl.size)
        lbl.bind(pos=lambda i,v: setattr(i._bg,"pos",v),
                 size=lambda i,v: setattr(i._bg,"size",v))
        self.content.add_widget(lbl)

    def _stat_card(self, label, value, color):
        row = BoxLayout(size_hint_y=None, height=dp(36),
                        padding=[dp(8), dp(4)])
        with row.canvas.before:
            Color(*PANEL)
            row._bg = RoundedRectangle(pos=row.pos, size=row.size, radius=[dp(4)])
        row.bind(pos=lambda i,v: setattr(i._bg,"pos",v),
                 size=lambda i,v: setattr(i._bg,"size",v))
        row.add_widget(make_label(label, size=11, color=DIM, size_hint_x=0.5))
        row.add_widget(make_label(value, size=12, color=color, bold=True,
                                   size_hint_x=0.5, halign="right"))
        self.content.add_widget(row)

    def _refresh_now(self, *_):
        self.app.pool_monitor.start()  # triggers one poll cycle
        Clock.schedule_once(lambda dt: self._render_tab(self._active_tab), 3)

    def _auto_refresh(self, dt):
        self._render_tab(self._active_tab)

    def _go_back(self, *_):
        self.manager.transition = SlideTransition(direction="right")
        self.manager.current = "dashboard"


# ═══════════════════════════════════════════════════════════════════════════════
# Main App
# ═══════════════════════════════════════════════════════════════════════════════
class TriMinerApp(App):
    def __init__(self, **kw):
        super().__init__(**kw)
        self.title = "TriMiner"
        self.config = {}
        self.monitor_data = {"duino": {}, "nimiq": {}, "riecoin": {}}

        # Shared miner state (written by background threads, read by UI)
        self.state = {
            "duino":   {"running": False, "hashrate": 0, "accepted": 0,
                        "rejected": 0, "diff": "--", "earned": 0, "new_logs": []},
            "nimiq":   {"running": False, "hashrate": 0, "accepted": 0,
                        "rejected": 0, "diff": "--", "earned": 0, "new_logs": []},
            "riecoin": {"running": False, "hashrate": 0, "accepted": 0,
                        "rejected": 0, "diff": "--", "earned": 0, "new_logs": []},
        }

        self.miners = {}
        self.pool_monitor = None

    def build(self):
        sm = ScreenManager()
        sm.add_widget(SetupScreen(self, name="setup"))
        sm.add_widget(DashboardScreen(self, name="dashboard"))
        sm.add_widget(MonitorScreen(self, name="monitor"))
        return sm

    # ── Miner lifecycle ───────────────────────────────────────────────────────
    def start_all_miners(self):
        for coin in ["duino", "nimiq", "riecoin"]:
            self.start_miner(coin)
        self._start_pool_monitor()

    def start_miner(self, coin):
        cfg = self.config
        st  = self.state[coin]

        def on_status(msg, level):
            st["new_logs"].append((msg, level))

        def on_share(acc, rej):
            st["accepted"] = acc
            st["rejected"] = rej

        def on_hashrate(hr):
            st["hashrate"] = hr

        if coin == "duino":
            if not cfg.get("duino_user"):
                st["new_logs"].append(("No username set", "err")); return
            m = DuinoMiner(
                username=cfg["duino_user"],
                password=cfg.get("duino_pass", ""),
                threads=cfg.get("duino_threads", 2),
                on_status=on_status, on_share=on_share, on_hashrate=on_hashrate
            )

        elif coin == "nimiq":
            if not cfg.get("nimiq_wallet"):
                st["new_logs"].append(("No wallet set", "err")); return
            host, port = self._split_host(cfg["nimiq_pool"], "eu.nimpool.io", 8444)
            m = NimiqMiner(
                wallet_address=cfg["nimiq_wallet"],
                threads=cfg.get("nimiq_threads", 2),
                pool_host=host, pool_port=port,
                on_status=on_status, on_share=on_share, on_hashrate=on_hashrate
            )

        elif coin == "riecoin":
            if not cfg.get("riec_wallet"):
                st["new_logs"].append(("No wallet set", "err")); return
            host, port = self._split_host(cfg["riec_pool"], "ric.riesenprime.de", 5000)
            m = RiecoinMiner(
                wallet_address=cfg["riec_wallet"],
                threads=cfg.get("riec_threads", 2),
                pool_host=host, pool_port=port,
                on_status=on_status, on_share=on_share, on_hashrate=on_hashrate
            )

        self.miners[coin] = m
        st["running"] = True
        m.start()

    def stop_miner(self, coin):
        if coin in self.miners:
            self.miners[coin].stop()
            self.state[coin]["running"] = False
            self.state[coin]["hashrate"] = 0

    def stop_all_miners(self):
        for coin in list(self.miners.keys()):
            self.stop_miner(coin)
        if self.pool_monitor:
            self.pool_monitor.stop()

    def _start_pool_monitor(self):
        cfg = self.config
        def on_update(coin, data):
            self.monitor_data[coin] = data
        self.pool_monitor = PoolMonitor(
            duino_user=cfg.get("duino_user",""),
            nimiq_wallet=cfg.get("nimiq_wallet",""),
            riecoin_wallet=cfg.get("riec_wallet",""),
            on_update=on_update
        )
        self.pool_monitor.start()

    @staticmethod
    def _split_host(host_str, default_host, default_port):
        try:
            parts = host_str.split(":")
            return parts[0], int(parts[1]) if len(parts) > 1 else default_port
        except Exception:
            return default_host, default_port

    def on_stop(self):
        self.stop_all_miners()


if __name__ == "__main__":
    TriMinerApp().run()
