"""
Pool Monitor — fetches live stats from Duino-Coin, Nimiq, and Riecoin pools/APIs
"""

import requests
import threading
import time
from datetime import datetime


class PoolMonitor:
    def __init__(self, duino_user="", nimiq_wallet="", riecoin_wallet="",
                 on_update=None):
        self.duino_user     = duino_user
        self.nimiq_wallet   = nimiq_wallet
        self.riecoin_wallet = riecoin_wallet
        self.on_update      = on_update  # callback(coin, data_dict)
        self.running        = False

    def start(self):
        self.running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def stop(self):
        self.running = False

    def _loop(self):
        while self.running:
            if self.duino_user:
                self._fetch_duino()
            if self.nimiq_wallet:
                self._fetch_nimiq()
            if self.riecoin_wallet:
                self._fetch_riecoin()
            time.sleep(30)  # poll every 30 seconds

    # ── Duino-Coin ─────────────────────────────────────────────────────────────
    def _fetch_duino(self):
        try:
            # User balance + stats
            url = f"https://server.duinocoin.com/v4/users/{self.duino_user}"
            r = requests.get(url, timeout=10)
            d = r.json()
            result = d.get("result", {})
            bal_data = result.get("balance", {})

            # Pool global stats
            ps = requests.get("https://server.duinocoin.com/v4/statistics", timeout=10).json()
            pool_data = ps.get("result", {})

            data = {
                "balance":       round(float(bal_data.get("balance", 0)), 6),
                "hashrate":      bal_data.get("hashrate", "0"),
                "workers":       bal_data.get("workers", 0),
                "total_earned":  round(float(bal_data.get("balance", 0)), 6),
                "pool_hashrate": pool_data.get("Pool hashrate", "N/A"),
                "active_miners": pool_data.get("Active miners", "N/A"),
                "difficulty":    pool_data.get("Current difficulty", "N/A"),
                "price_usd":     pool_data.get("Duco price", "N/A"),
                "blocks_found":  pool_data.get("Blocks found", "N/A"),
                "last_updated":  datetime.now().strftime("%H:%M:%S"),
            }
            if self.on_update:
                self.on_update("duino", data)
        except Exception as e:
            if self.on_update:
                self.on_update("duino", {"error": str(e)})

    # ── Nimiq ──────────────────────────────────────────────────────────────────
    def _fetch_nimiq(self):
        try:
            # Miner stats
            url = f"https://nimpool.io/api/miner/{self.nimiq_wallet}"
            r = requests.get(url, timeout=10)
            md = r.json()

            # Pool stats
            ps = requests.get("https://nimpool.io/api/pool", timeout=10).json()

            data = {
                "balance":        md.get("balance", 0),
                "hashrate":       md.get("hashrate", 0),
                "shares_valid":   md.get("validShares", 0),
                "shares_invalid": md.get("invalidShares", 0),
                "last_share":     md.get("lastShare", "N/A"),
                "workers":        md.get("workers", []),
                "pool_hashrate":  ps.get("hashrate", "N/A"),
                "pool_miners":    ps.get("minersTotal", "N/A"),
                "pool_fee":       ps.get("poolFee", "N/A"),
                "block_time":     ps.get("blockTime", "N/A"),
                "nim_price_usd":  ps.get("price", "N/A"),
                "last_block":     ps.get("lastBlockFound", "N/A"),
                "last_updated":   datetime.now().strftime("%H:%M:%S"),
            }
            if self.on_update:
                self.on_update("nimiq", data)
        except Exception as e:
            if self.on_update:
                self.on_update("nimiq", {"error": str(e)})

    # ── Riecoin ────────────────────────────────────────────────────────────────
    def _fetch_riecoin(self):
        try:
            url = f"https://ric.riesenprime.de/api/miner/{self.riecoin_wallet}"
            r = requests.get(url, timeout=10)
            md = r.json()

            ps = requests.get("https://ric.riesenprime.de/api/pool", timeout=10).json()

            data = {
                "balance":       md.get("balance", 0),
                "hashrate":      md.get("hashrate", 0),
                "shares_valid":  md.get("validShares", 0),
                "shares_stale":  md.get("staleShares", 0),
                "last_share":    md.get("lastShare", "N/A"),
                "tuple_type":    md.get("tupleType", "6-tuple"),
                "pool_hashrate": ps.get("hashrate", "N/A"),
                "pool_miners":   ps.get("miners", "N/A"),
                "pool_fee":      ps.get("fee", "N/A"),
                "ric_price_usd": ps.get("price", "N/A"),
                "last_block":    ps.get("lastBlock", "N/A"),
                "network_diff":  ps.get("networkDifficulty", "N/A"),
                "last_updated":  datetime.now().strftime("%H:%M:%S"),
            }
            if self.on_update:
                self.on_update("riecoin", data)
        except Exception as e:
            if self.on_update:
                self.on_update("riecoin", {"error": str(e)})
